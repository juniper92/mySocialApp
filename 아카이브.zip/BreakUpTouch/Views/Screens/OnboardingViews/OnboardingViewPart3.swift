//
//  OnboardingViewPart3.swift
//  BreakUpTouch
//
//  Created by HI on 2021/10/18.
//

import SwiftUI

struct OnboardingViewPart3: View {
    var body: some View {
        Text("온보딩뷰 3")
    }
}

struct OnboardingViewPart3_Previews: PreviewProvider {
    static var previews: some View {
        OnboardingViewPart3()
    }
}
