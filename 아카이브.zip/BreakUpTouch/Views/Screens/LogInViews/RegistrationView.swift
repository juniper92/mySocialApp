//
//  RegistrationView.swift
//  BreakUpTouch
//
//  Created by HI on 2021/10/11.
//

import SwiftUI

struct RegistrationView: View {
    var body: some View {
        Text("회원가입창")
    }
}

struct RegistrationView_Previews: PreviewProvider {
    static var previews: some View {
        RegistrationView()
    }
}
