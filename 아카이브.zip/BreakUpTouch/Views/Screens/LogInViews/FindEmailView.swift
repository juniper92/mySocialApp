//
//  FindEmailView.swift
//  BreakUpTouch
//
//  Created by HI on 2021/10/11.
//

import SwiftUI

struct FindEmailView: View {
    var body: some View {
        Text("이메일 찾기")
    }
}

struct FindEmailView_Previews: PreviewProvider {
    static var previews: some View {
        FindEmailView()
    }
}
