//
//  FindPasswordView.swift
//  BreakUpTouch
//
//  Created by HI on 2021/10/11.
//

import SwiftUI

struct FindPasswordView: View {
    var body: some View {
        Text("비밀번호 찾기")
    }
}

struct FindPasswordView_Previews: PreviewProvider {
    static var previews: some View {
        FindPasswordView()
    }
}
