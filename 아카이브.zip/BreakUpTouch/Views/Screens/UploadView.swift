//
//  UploadView.swift
//  BreakUpTouch
//
//  Created by HI on 2021/09/27.
//

import SwiftUI

struct UploadView: View {
    var body: some View {
        Text("게시글 작성")
    }
}

struct UploadView_Previews: PreviewProvider {
    static var previews: some View {
        UploadView()
    }
}
