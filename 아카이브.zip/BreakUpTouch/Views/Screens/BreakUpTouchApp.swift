//
//  BreakUpTouchApp.swift
//  BreakUpTouch
//
//  Created by HI on 2021/09/17.
//

import SwiftUI

@main
struct BreakUpTouchApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
